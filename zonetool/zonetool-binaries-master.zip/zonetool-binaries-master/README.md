![license](https://img.shields.io/github/license/ZoneTool/zonetool-binaries.svg)
![stars](https://img.shields.io/github/stars/ZoneTool/zonetool-binaries.svg)
[![discord](https://discordapp.com/api/guilds/290238678352134145/widget.png)](https://discord.gg/a6JM2Tv)
<p align="center"><img src="plutonium_logo.jpg" alt="Plutonium"/>

# zonetool-binaries
this repository contains the binaries required to run zonetool.
